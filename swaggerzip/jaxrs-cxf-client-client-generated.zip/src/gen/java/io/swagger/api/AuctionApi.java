package io.swagger.api;

import io.swagger.model.AuctionDto;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;
import javax.ws.rs.*;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.MediaType;
import org.apache.cxf.jaxrs.ext.multipart.*;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponses;
import io.swagger.annotations.ApiResponse;
import io.swagger.jaxrs.PATCH;

/**
 * Rishis Auction API
 *
 * <p>The Auction API. More features will follow. 
 *
 */
@Path("/")
@Api(value = "/", description = "")
public interface AuctionApi  {

    /**
     * Retrieve an auction by id.
     *
     * 
     *
     */
    @GET
    @Path("/auctionitems/{auctionitemid}")
    @Produces({ "application/json" })
    @ApiOperation(value = "Retrieve an auction by id.", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "Successful retrieval of the auction.", response = AuctionDto.class),
        @ApiResponse(code = 400, message = "No auction found for given id."),
        @ApiResponse(code = 403, message = "You can't view the auction details as the state is not supported!") })
    public AuctionDto getAuctionById(@PathParam("auctionitemid") Long auctionitemid);

    /**
     * Retrieve a list of auctions.
     *
     * 
     *
     */
    @GET
    @Path("/auctionitems")
    @Produces({ "application/json" })
    @ApiOperation(value = "Retrieve a list of auctions.", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "Successful retrieval of auctions.", response = AuctionDto.class, responseContainer = "List"),
        @ApiResponse(code = 400, message = "No auctions were found.") })
    public List<AuctionDto> getAuctionItems(@QueryParam("auctionItemId")Long auctionItemId, @QueryParam("currentBid")String currentBid, @QueryParam("reservePrice")String reservePrice, @QueryParam("bidderName")String bidderName, @QueryParam("item")String item);
}

