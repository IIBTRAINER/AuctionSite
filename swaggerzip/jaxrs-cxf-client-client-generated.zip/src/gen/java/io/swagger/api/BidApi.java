package io.swagger.api;

import io.swagger.model.BidDto;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;
import javax.ws.rs.*;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.MediaType;
import org.apache.cxf.jaxrs.ext.multipart.*;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponses;
import io.swagger.annotations.ApiResponse;
import io.swagger.jaxrs.PATCH;

/**
 * Rishis Auction API
 *
 * <p>The Auction API. More features will follow. 
 *
 */
@Path("/")
@Api(value = "/", description = "")
public interface BidApi  {

    /**
     * Deletes a bid
     *
     * 
     *
     */
    @DELETE
    @Path("/bid/{id}")
    @Produces({ "application/json" })
    @ApiOperation(value = "Deletes a bid", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(code = 204, message = "successful operation"),
        @ApiResponse(code = 401, message = "no valid token added to authorization header"),
        @ApiResponse(code = 404, message = "bid not found") })
    public void deleteBid(@PathParam("id") Long id);

    /**
     * Returns a bid
     *
     * 
     *
     */
    @GET
    @Path("/bid/{id}")
    @Produces({ "application/json" })
    @ApiOperation(value = "Returns a bid", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "successful operation", response = BidDto.class),
        @ApiResponse(code = 401, message = "no valid token added to authorization header"),
        @ApiResponse(code = 404, message = "bid not found") })
    public BidDto getBid(@PathParam("id") Long id);

    /**
     * Returns bids of an auction
     *
     * 
     *
     */
    @GET
    @Path("/bid")
    @Produces({ "application/json" })
    @ApiOperation(value = "Returns bids of an auction", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "successful operation", response = BidDto.class, responseContainer = "List"),
        @ApiResponse(code = 401, message = "no valid token added to authorization header"),
        @ApiResponse(code = 404, message = "bid not found") })
    public List<BidDto> getBidsOfAuction(@QueryParam("auctionId")Long auctionId);

    /**
     * Bids on an short-term auction or bids on the first round of a long-term auction
     *
     * 
     *
     */
    @POST
    @Path("/bid")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @ApiOperation(value = "Bids on an short-term auction or bids on the first round of a long-term auction", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(code = 201, message = "successful operation", response = BidDto.class),
        @ApiResponse(code = 400, message = "validation error"),
        @ApiResponse(code = 401, message = "no valid token added to authorization header"),
        @ApiResponse(code = 404, message = "Auction, User, BalancingGroup or PortfolioCode not found") })
    public BidDto submitBid(BidDto body);

    /**
     * Updates a bid. This can also be used to update the quantity of your bid for later auction rounds.
     *
     * 
     *
     */
    @PUT
    @Path("/bid/{id}")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @ApiOperation(value = "Updates a bid. This can also be used to update the quantity of your bid for later auction rounds.", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(code = 400, message = "validation error"),
        @ApiResponse(code = 401, message = "no valid token added to authorization header"),
        @ApiResponse(code = 404, message = "Bid, Auction not found") })
    public void updateBid(@PathParam("id") Long id, BidDto body);
}

