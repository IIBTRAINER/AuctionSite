package io.swagger.model;


import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class BidDto  {
  
  @ApiModelProperty(value = "Must not be set on upload")
 /**
   * Must not be set on upload
  **/
  private Long auctionItemId = null;

  @ApiModelProperty(value = "")
  private String maxAutoBidAmount = null;

  @ApiModelProperty(required = true, value = "")
  private String biddrerName = null;
 /**
   * Must not be set on upload
   * @return auctionItemId
  **/
  @JsonProperty("auctionItemId")
  public Long getAuctionItemId() {
    return auctionItemId;
  }


 /**
   * Get maxAutoBidAmount
   * @return maxAutoBidAmount
  **/
  @JsonProperty("maxAutoBidAmount")
  public String getMaxAutoBidAmount() {
    return maxAutoBidAmount;
  }

  public void setMaxAutoBidAmount(String maxAutoBidAmount) {
    this.maxAutoBidAmount = maxAutoBidAmount;
  }

  public BidDto maxAutoBidAmount(String maxAutoBidAmount) {
    this.maxAutoBidAmount = maxAutoBidAmount;
    return this;
  }

 /**
   * Get biddrerName
   * @return biddrerName
  **/
  @JsonProperty("biddrerName")
  public String getBiddrerName() {
    return biddrerName;
  }

  public void setBiddrerName(String biddrerName) {
    this.biddrerName = biddrerName;
  }

  public BidDto biddrerName(String biddrerName) {
    this.biddrerName = biddrerName;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class BidDto {\n");
    
    sb.append("    auctionItemId: ").append(toIndentedString(auctionItemId)).append("\n");
    sb.append("    maxAutoBidAmount: ").append(toIndentedString(maxAutoBidAmount)).append("\n");
    sb.append("    biddrerName: ").append(toIndentedString(biddrerName)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

