package io.swagger.model;

import io.swagger.model.ItemsDto;
import java.util.ArrayList;
import java.util.List;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class AuctionDto  {
  
  @ApiModelProperty(value = "")
  private Long auctionItemId = null;

  @ApiModelProperty(value = "")
  private String currentBid = null;

  @ApiModelProperty(value = "")
  private String reservePrice = null;

  @ApiModelProperty(value = "")
  private String bidderName = null;

  @ApiModelProperty(value = "")
  private List<ItemsDto> items = null;
 /**
   * Get auctionItemId
   * @return auctionItemId
  **/
  @JsonProperty("auctionItemId")
  public Long getAuctionItemId() {
    return auctionItemId;
  }

  public void setAuctionItemId(Long auctionItemId) {
    this.auctionItemId = auctionItemId;
  }

  public AuctionDto auctionItemId(Long auctionItemId) {
    this.auctionItemId = auctionItemId;
    return this;
  }

 /**
   * Get currentBid
   * @return currentBid
  **/
  @JsonProperty("currentBid")
  public String getCurrentBid() {
    return currentBid;
  }

  public void setCurrentBid(String currentBid) {
    this.currentBid = currentBid;
  }

  public AuctionDto currentBid(String currentBid) {
    this.currentBid = currentBid;
    return this;
  }

 /**
   * Get reservePrice
   * @return reservePrice
  **/
  @JsonProperty("reservePrice")
  public String getReservePrice() {
    return reservePrice;
  }

  public void setReservePrice(String reservePrice) {
    this.reservePrice = reservePrice;
  }

  public AuctionDto reservePrice(String reservePrice) {
    this.reservePrice = reservePrice;
    return this;
  }

 /**
   * Get bidderName
   * @return bidderName
  **/
  @JsonProperty("bidderName")
  public String getBidderName() {
    return bidderName;
  }

  public void setBidderName(String bidderName) {
    this.bidderName = bidderName;
  }

  public AuctionDto bidderName(String bidderName) {
    this.bidderName = bidderName;
    return this;
  }

 /**
   * Get items
   * @return items
  **/
  @JsonProperty("items")
  public List<ItemsDto> getItems() {
    return items;
  }

  public void setItems(List<ItemsDto> items) {
    this.items = items;
  }

  public AuctionDto items(List<ItemsDto> items) {
    this.items = items;
    return this;
  }

  public AuctionDto addItemsItem(ItemsDto itemsItem) {
    this.items.add(itemsItem);
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class AuctionDto {\n");
    
    sb.append("    auctionItemId: ").append(toIndentedString(auctionItemId)).append("\n");
    sb.append("    currentBid: ").append(toIndentedString(currentBid)).append("\n");
    sb.append("    reservePrice: ").append(toIndentedString(reservePrice)).append("\n");
    sb.append("    bidderName: ").append(toIndentedString(bidderName)).append("\n");
    sb.append("    items: ").append(toIndentedString(items)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

