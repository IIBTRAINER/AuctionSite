package io.swagger.api;

import io.swagger.model.BidDto;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.swagger.annotations.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.constraints.*;
import javax.validation.Valid;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.List;
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-08-18T21:56:30.616Z")

@Controller
public class BidApiController implements BidApi {

    private static final Logger log = LoggerFactory.getLogger(BidApiController.class);

    private final ObjectMapper objectMapper;

    private final HttpServletRequest request;

    @org.springframework.beans.factory.annotation.Autowired
    public BidApiController(ObjectMapper objectMapper, HttpServletRequest request) {
        this.objectMapper = objectMapper;
        this.request = request;
    }

    public ResponseEntity<Void> deleteBid(@ApiParam(value = "",required=true) @PathVariable("id") Long id) {
        String accept = request.getHeader("Accept");
        return new ResponseEntity<Void>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<BidDto> getBid(@ApiParam(value = "Id of the bid",required=true) @PathVariable("id") Long id) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<BidDto>(objectMapper.readValue("{  \"auctionItemId\" : 0,  \"maxAutoBidAmount\" : \"maxAutoBidAmount\",  \"biddrerName\" : \"biddrerName\"}", BidDto.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<BidDto>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<BidDto>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<List<BidDto>> getBidsOfAuction(@NotNull @ApiParam(value = "Id of the auction", required = true) @Valid @RequestParam(value = "auctionId", required = true) Long auctionId) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<List<BidDto>>(objectMapper.readValue("[ {  \"auctionItemId\" : 0,  \"maxAutoBidAmount\" : \"maxAutoBidAmount\",  \"biddrerName\" : \"biddrerName\"}, {  \"auctionItemId\" : 0,  \"maxAutoBidAmount\" : \"maxAutoBidAmount\",  \"biddrerName\" : \"biddrerName\"} ]", List.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<List<BidDto>>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<List<BidDto>>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<BidDto> submitBid(@ApiParam(value = ""  )  @Valid @RequestBody BidDto body) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<BidDto>(objectMapper.readValue("{  \"auctionItemId\" : 0,  \"maxAutoBidAmount\" : \"maxAutoBidAmount\",  \"biddrerName\" : \"biddrerName\"}", BidDto.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<BidDto>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<BidDto>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<Void> updateBid(@ApiParam(value = "Id of the bid",required=true) @PathVariable("id") Long id,@ApiParam(value = ""  )  @Valid @RequestBody BidDto body) {
        String accept = request.getHeader("Accept");
        return new ResponseEntity<Void>(HttpStatus.NOT_IMPLEMENTED);
    }

}
