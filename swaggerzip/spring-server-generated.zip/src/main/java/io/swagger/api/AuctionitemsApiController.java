package io.swagger.api;

import io.swagger.model.AuctionDto;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.swagger.annotations.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.constraints.*;
import javax.validation.Valid;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.List;
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-08-18T21:56:30.616Z")

@Controller
public class AuctionitemsApiController implements AuctionitemsApi {

    private static final Logger log = LoggerFactory.getLogger(AuctionitemsApiController.class);

    private final ObjectMapper objectMapper;

    private final HttpServletRequest request;

    @org.springframework.beans.factory.annotation.Autowired
    public AuctionitemsApiController(ObjectMapper objectMapper, HttpServletRequest request) {
        this.objectMapper = objectMapper;
        this.request = request;
    }

    public ResponseEntity<AuctionDto> getAuctionById(@ApiParam(value = "Id of the auction",required=true) @PathVariable("auctionitemid") Long auctionitemid) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<AuctionDto>(objectMapper.readValue("{  \"auctionItemId\" : 0,  \"reservePrice\" : \"reservePrice\",  \"currentBid\" : \"currentBid\",  \"bidderName\" : \"bidderName\",  \"items\" : [ {    \"itemid\" : 6,    \"itemDescription\" : \"itemDescription\"  }, {    \"itemid\" : 6,    \"itemDescription\" : \"itemDescription\"  } ]}", AuctionDto.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<AuctionDto>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<AuctionDto>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<List<AuctionDto>> getAuctionItems(@ApiParam(value = "Auction Item Id") @Valid @RequestParam(value = "auctionItemId", required = false) Long auctionItemId,@ApiParam(value = "Current Bid") @Valid @RequestParam(value = "currentBid", required = false) String currentBid,@ApiParam(value = "Reserve Price") @Valid @RequestParam(value = "reservePrice", required = false) String reservePrice,@ApiParam(value = "Bidder Name") @Valid @RequestParam(value = "bidderName", required = false) String bidderName,@ApiParam(value = "item Description") @Valid @RequestParam(value = "item", required = false) String item) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<List<AuctionDto>>(objectMapper.readValue("[ {  \"auctionItemId\" : 0,  \"reservePrice\" : \"reservePrice\",  \"currentBid\" : \"currentBid\",  \"bidderName\" : \"bidderName\",  \"items\" : [ {    \"itemid\" : 6,    \"itemDescription\" : \"itemDescription\"  }, {    \"itemid\" : 6,    \"itemDescription\" : \"itemDescription\"  } ]}, {  \"auctionItemId\" : 0,  \"reservePrice\" : \"reservePrice\",  \"currentBid\" : \"currentBid\",  \"bidderName\" : \"bidderName\",  \"items\" : [ {    \"itemid\" : 6,    \"itemDescription\" : \"itemDescription\"  }, {    \"itemid\" : 6,    \"itemDescription\" : \"itemDescription\"  } ]} ]", List.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<List<AuctionDto>>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<List<AuctionDto>>(HttpStatus.NOT_IMPLEMENTED);
    }

}
