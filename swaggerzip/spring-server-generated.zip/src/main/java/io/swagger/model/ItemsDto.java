package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * ItemsDto
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-08-18T21:56:30.616Z")

public class ItemsDto   {
  @JsonProperty("itemid")
  private Long itemid = null;

  @JsonProperty("itemDescription")
  private String itemDescription = null;

  public ItemsDto itemid(Long itemid) {
    this.itemid = itemid;
    return this;
  }

  /**
   * Get itemid
   * @return itemid
  **/
  @ApiModelProperty(value = "")


  public Long getItemid() {
    return itemid;
  }

  public void setItemid(Long itemid) {
    this.itemid = itemid;
  }

  public ItemsDto itemDescription(String itemDescription) {
    this.itemDescription = itemDescription;
    return this;
  }

  /**
   * Get itemDescription
   * @return itemDescription
  **/
  @ApiModelProperty(value = "")


  public String getItemDescription() {
    return itemDescription;
  }

  public void setItemDescription(String itemDescription) {
    this.itemDescription = itemDescription;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ItemsDto itemsDto = (ItemsDto) o;
    return Objects.equals(this.itemid, itemsDto.itemid) &&
        Objects.equals(this.itemDescription, itemsDto.itemDescription);
  }

  @Override
  public int hashCode() {
    return Objects.hash(itemid, itemDescription);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ItemsDto {\n");
    
    sb.append("    itemid: ").append(toIndentedString(itemid)).append("\n");
    sb.append("    itemDescription: ").append(toIndentedString(itemDescription)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

