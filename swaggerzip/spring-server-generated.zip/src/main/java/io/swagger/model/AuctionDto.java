package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.ItemsDto;
import java.util.ArrayList;
import java.util.List;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * AuctionDto
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-08-18T21:56:30.616Z")

public class AuctionDto   {
  @JsonProperty("auctionItemId")
  private Long auctionItemId = null;

  @JsonProperty("currentBid")
  private String currentBid = null;

  @JsonProperty("reservePrice")
  private String reservePrice = null;

  @JsonProperty("bidderName")
  private String bidderName = null;

  @JsonProperty("items")
  @Valid
  private List<ItemsDto> items = null;

  public AuctionDto auctionItemId(Long auctionItemId) {
    this.auctionItemId = auctionItemId;
    return this;
  }

  /**
   * Get auctionItemId
   * @return auctionItemId
  **/
  @ApiModelProperty(value = "")


  public Long getAuctionItemId() {
    return auctionItemId;
  }

  public void setAuctionItemId(Long auctionItemId) {
    this.auctionItemId = auctionItemId;
  }

  public AuctionDto currentBid(String currentBid) {
    this.currentBid = currentBid;
    return this;
  }

  /**
   * Get currentBid
   * @return currentBid
  **/
  @ApiModelProperty(value = "")


  public String getCurrentBid() {
    return currentBid;
  }

  public void setCurrentBid(String currentBid) {
    this.currentBid = currentBid;
  }

  public AuctionDto reservePrice(String reservePrice) {
    this.reservePrice = reservePrice;
    return this;
  }

  /**
   * Get reservePrice
   * @return reservePrice
  **/
  @ApiModelProperty(value = "")


  public String getReservePrice() {
    return reservePrice;
  }

  public void setReservePrice(String reservePrice) {
    this.reservePrice = reservePrice;
  }

  public AuctionDto bidderName(String bidderName) {
    this.bidderName = bidderName;
    return this;
  }

  /**
   * Get bidderName
   * @return bidderName
  **/
  @ApiModelProperty(value = "")


  public String getBidderName() {
    return bidderName;
  }

  public void setBidderName(String bidderName) {
    this.bidderName = bidderName;
  }

  public AuctionDto items(List<ItemsDto> items) {
    this.items = items;
    return this;
  }

  public AuctionDto addItemsItem(ItemsDto itemsItem) {
    if (this.items == null) {
      this.items = new ArrayList<ItemsDto>();
    }
    this.items.add(itemsItem);
    return this;
  }

  /**
   * Get items
   * @return items
  **/
  @ApiModelProperty(value = "")

  @Valid

  public List<ItemsDto> getItems() {
    return items;
  }

  public void setItems(List<ItemsDto> items) {
    this.items = items;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    AuctionDto auctionDto = (AuctionDto) o;
    return Objects.equals(this.auctionItemId, auctionDto.auctionItemId) &&
        Objects.equals(this.currentBid, auctionDto.currentBid) &&
        Objects.equals(this.reservePrice, auctionDto.reservePrice) &&
        Objects.equals(this.bidderName, auctionDto.bidderName) &&
        Objects.equals(this.items, auctionDto.items);
  }

  @Override
  public int hashCode() {
    return Objects.hash(auctionItemId, currentBid, reservePrice, bidderName, items);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class AuctionDto {\n");
    
    sb.append("    auctionItemId: ").append(toIndentedString(auctionItemId)).append("\n");
    sb.append("    currentBid: ").append(toIndentedString(currentBid)).append("\n");
    sb.append("    reservePrice: ").append(toIndentedString(reservePrice)).append("\n");
    sb.append("    bidderName: ").append(toIndentedString(bidderName)).append("\n");
    sb.append("    items: ").append(toIndentedString(items)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

