package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * BidDto
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-08-18T21:56:30.616Z")

public class BidDto   {
  @JsonProperty("auctionItemId")
  private Long auctionItemId = null;

  @JsonProperty("maxAutoBidAmount")
  private String maxAutoBidAmount = null;

  @JsonProperty("biddrerName")
  private String biddrerName = null;

  public BidDto auctionItemId(Long auctionItemId) {
    this.auctionItemId = auctionItemId;
    return this;
  }

  /**
   * Must not be set on upload
   * @return auctionItemId
  **/
  @ApiModelProperty(readOnly = true, value = "Must not be set on upload")


  public Long getAuctionItemId() {
    return auctionItemId;
  }

  public void setAuctionItemId(Long auctionItemId) {
    this.auctionItemId = auctionItemId;
  }

  public BidDto maxAutoBidAmount(String maxAutoBidAmount) {
    this.maxAutoBidAmount = maxAutoBidAmount;
    return this;
  }

  /**
   * Get maxAutoBidAmount
   * @return maxAutoBidAmount
  **/
  @ApiModelProperty(value = "")


  public String getMaxAutoBidAmount() {
    return maxAutoBidAmount;
  }

  public void setMaxAutoBidAmount(String maxAutoBidAmount) {
    this.maxAutoBidAmount = maxAutoBidAmount;
  }

  public BidDto biddrerName(String biddrerName) {
    this.biddrerName = biddrerName;
    return this;
  }

  /**
   * Get biddrerName
   * @return biddrerName
  **/
  @ApiModelProperty(required = true, value = "")
  @NotNull


  public String getBiddrerName() {
    return biddrerName;
  }

  public void setBiddrerName(String biddrerName) {
    this.biddrerName = biddrerName;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    BidDto bidDto = (BidDto) o;
    return Objects.equals(this.auctionItemId, bidDto.auctionItemId) &&
        Objects.equals(this.maxAutoBidAmount, bidDto.maxAutoBidAmount) &&
        Objects.equals(this.biddrerName, bidDto.biddrerName);
  }

  @Override
  public int hashCode() {
    return Objects.hash(auctionItemId, maxAutoBidAmount, biddrerName);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class BidDto {\n");
    
    sb.append("    auctionItemId: ").append(toIndentedString(auctionItemId)).append("\n");
    sb.append("    maxAutoBidAmount: ").append(toIndentedString(maxAutoBidAmount)).append("\n");
    sb.append("    biddrerName: ").append(toIndentedString(biddrerName)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

